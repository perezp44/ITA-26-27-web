#- script para seguir las slides_03 (R-base)

#- pp. 5 -----------------------------------------------------------------------
#- Creación de objetos y asignación (<-)

#- ¿Qué diferencias hay entre las siguientes 2 expresiones?
2 + 2
aa <- 2 + 2
#- una vez hemos creado una variable, podemos usarla para efectuar nuevos cálculos
aa + 1
#- podemos cambiar el valor de una variable
aa
aa <- 10
aa
#- ¿Qué hacen las siguientes lineas de código? 
aa <- 2 + 2
bb <- 5 + aa
cc <- 1 + aa * 2
dd <- bb


#- pp. 6 -----------------------------------------------------------------------
#- Global environment (primera referencia al)

aa <- 2 + 2
bb <- 5 + aa
cc <- 1 + aa * 2
dd <- bb
ls()              #- muestra los objetos q hay en el  Global env. 
rm(cc)            #- borra/elimina el objeto cc del Global env.
rm(list = ls())   #- borra todos los objetos del Global env.



#- pp. 8 -----------------------------------------------------------------------
#- tipos de datos

aa <- "La calle en la que vivo es"    #- texto (character)
bb <- 4L                              #- número entero
cc <- 4.3                             #- número decimal
dd <- TRUE                            #- logical
typeof(aa)
typeof(dd)


#- pp. 9 -----------------------------------------------------------------------
#- Operaciones con variables numéricas

#- operaciones aritméticas
2 + 2
5 * 6

#- operaciones de comparación
2 < 4    # MENOR que: esta expresión chequea si 2 es MENOR que cuatro. Como es cierto, nos devuelve un TRUE
2 > 4    # MAYOR que: esta expresión chequea si 2 es MAYOR que cuatro. Como es cierto, nos devuelve un TRUE
5 >= 7   # MAYOR o IGUAL que.
8 <= 8   # MENOR o IGUAL que.
5 == 4  # == IGUAL: == chequea si dos valores son iguales, como no son iguales devolverá FALSE
2 != 4   # NO IGUAL: como 2 no es igual a 4 nos devuelve TRUE
5 != 5   # NO IGUAL: como 5 es igual a 5, nos devuelve FALSE


#- ¿qué ocurre? ¿xq se queja R?
2 = 2   


#- pp. 10 ----------------------------------------------------------------------
#- operaciones con texto

aa <- "mi nombre es"
bb <- "pedro"
paste(aa, bb)
paste(aa, bb, sep = " ... ")

# Prueba tú mismo que hace la función paste0()




#- 
toupper(aa)
tolower(aa)
nchar(bb)                      #- nchar() nos devuelve el número de caracteres de un string
substring(bb, 2, nchar(bb))    #- substring() extrae caracteres de un string  [🌶🌶]



#- pp. 11 ----------------------------------------------------------------------
#- Operaciones lógicas

#- AND: para q devuelva TRUE hace falta que TODAS las condiciones sean ciertas
(4 > 3) & (3 < 2)  #- AND: como solo se cumple la primera condición, nos devuelve FALSE

#- OR: devuelve TRUE si ALGUNA de las condiciones es cierta
(1==2) | (2 >3)   #- OR: Como no se cumple ninguna de las 2 condiciones nos devuelve FALSE

#- NOT: devuelve el valor contrario
!(4 > 3)          #- NOT: 4 es mayor que 3 es TRUE, pero el ! delante de esa condición la niega y pasa a FALSE

!!(4 > 3)         #- si niegas dos veces, vuelves al principio: TRUE


#- pp. 16 ----------------------------------------------------------------------
#- ¿Cómo crear un vector?

aa <- c(3, 22, 6)
aa
is.vector(aa)
typeof(aa)

#- TAREA: crea un vector de tipo character con 3 elementos



#- pp. 18 ----------------------------------------------------------------------
#- Subsetting con vectores

#- 1. Seleccionar por posición
aa <- c(10:1)
aa[c(1:2)]        #- primer y segundo elemento del vector
aa[c(1, 2, 9, 10)]   #- dos primeros y 2 últimos

#- Eliminar por posición
aa <- c(10:1)
aa[-2]
aa[- c(1, 2, 9:10)]

#- 3. Subsetting lógico
aa <- 1:10
aa[aa >= 7]
aa[aa < 4]
aa[(aa >= 9) | (aa < 2)]
aa[(aa >= 9) & (aa < 2)]




#- pp. 22 ----------------------------------------------------------------------
#- Creación de data frame's

#- creamos 3 vectores de la misma longitud
aa <- c(4, 8, 6, 3)
bb <- c("Juan", "Paz", "Adrian", "Marquitos")
cc <- c(FALSE, TRUE, TRUE, FALSE)
#- agrupamos los 3 vectores en un data.frame
df <- data.frame(aa, bb, cc)
#- veamos el data.frame. Veremos que las columnas tienen nombre
df

#- le pongo nombre a las columnas/variables
df <- data.frame(Nota = aa, Nombre = bb, Aprobado = cc)





#- pp. 23 ----------------------------------------------------------------------
#- Subsetting en data frames

#- subsetting como si fuera matriz (con [ )
df_s <- df[,1]        #- seleccionamos la primera columna

df_s <- df[,c(2,3)]   #- seleccionamos la segunda y tercera columna

df_s <- df[1, ]       #- seleccionamos primera fila de todas las variables. 


#- pp. 26 ----------------------------------------------------------------------
#- TAREA: crea una función que permita sumar 2 números






#- pp. 27 ----------------------------------------------------------------------
#- ayuda de las funciones : F1

help(sqrt)


#- pp. 28 ----------------------------------------------------------------------
#- seguimos con las funciones

#- Tarea:Ejecuta estas instrucciones e intenta entender que ocurre.

sqrt(9)
sqrt(9, 4)   #- no funciona, ¿por qué? ¿cuantos argumentos tiene la f. sqrt()?
sqrt("9")    #- no funciona, ¿por qué? ¿de que tipo ha de ser el argumento?



#- pp. 29 ----------------------------------------------------------------------
#- seguimos con las funciones (más detalles) [🌶🌶🌶]

sqrt(9)       #- en realidad "no hace falta" poner el nombre del argumento
sqrt(x = 9)   #- 
sqrt(x = 4)


#- Vamos a aprender a diferenciar el nombre y el valor del argumento de una función:
sqrt(9)
sqrt(x = 9)

x <- 25

sqrt(x)
sqrt(x = x)          #- !!! ¿cual es el nombre y el valor del argumento?
sqrt(x = un_valor)   #- !!! ¿qué ocurre?
sqrt(nn = 9)         #- !!! ¿qué ocurre?
  


#- pp. 32 ----------------------------------------------------------------------
#- ¿Cómo me instalo un paquete? (Forma habitual)

#- de CRAN
install.packages("dplyr")    #- instalamos el pkg dplyr en nuestro ordenador
library(dplyr)               #- cargamos dplyr en memoria de R para así poder usarlo

#- de Github
install.packages("remotes")    #- previamente hay que instalar el pkg remotes
remotes::install_github("tidyverse/dplyr")   #- instalamos la versión de github del pkg dplyr


#- los paquetes una vez instalados hay que cargarlos
library(dplyr)    #- cargamos dplyr en memoria de R para así poder usarlo